# Hardware-Localmachine:

## Overview

- Modellname:	MacBook Pro
- Modell-ID:	MacBookPro12,1
- Processortype:	Intel Core i5
- Processorspeed:	2,7 GHz
- Nr. of Processors:	1
- Nr. of Cores:	2
- L2-Cache (per Core):	256 KB
- L3-Cache:	3 MB
- Memory:	2 x 4 GB DDR3 1867 MHz

## Disk

- space available: 17.85 GB
- capacity: 120.12 GB
- FS: Journaled HFS+
- Type: SSD
- Protocol: PCI
